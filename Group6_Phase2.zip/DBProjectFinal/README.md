# DBProject
Included in this .zip are the UI implementation DBProject.py, as well as the Project report PDF. We have also included several test files, as well
as the randomizer program used to create them. 

This project must be run using Python 3. The program takes no paramteres so it may be run as follows: python3 DBProject.py
Any input files must be stored locally (full path is preferable).
It is assumed that the database and tables already exist.
